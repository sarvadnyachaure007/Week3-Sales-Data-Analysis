# Sales Data Analysis Report

## Project Overview
This project analyzes sample sales data using Python and pandas.

## Dataset
- Original rows: 16
- Records after duplicate removal: 15
- Duplicate rows removed: 1
- Missing values after cleaning: 0

## Key Metrics
| Metric | Result |
|---|---:|
| Total revenue | Rs. 302,400.00 |
| Average sale | Rs. 20,160.00 |
| Highest sale | Rs. 90,000.00 |
| Lowest sale | Rs. 1,000.00 |
| Total units sold | 64.00 |

## Best-Selling Products
- Best product by revenue: **Laptop**
- Best product by units sold: **Mouse**

## Revenue by Product
| Product    |   Revenue (Rs.) |
|:-----------|----------------:|
| Headphones |           20000 |
| Keyboard   |           14400 |
| Laptop     |          180000 |
| Monitor    |           72000 |
| Mouse      |           16000 |

## Cleaning Steps
1. Converted numeric fields to numeric types.
2. Removed duplicate records.
3. Filled missing sales from quantity and unit price.
4. Filled remaining missing quantities and prices with column medians.
5. Recalculated sales consistently.
6. Saved cleaned_sales_data.csv.

## Conclusion
The analysis calculates sales performance and identifies leading products.
All findings are based on the sample educational dataset.

## How to Run
Install dependencies using `python -m pip install -r requirements.txt`.
Run `python sales_analysis.py`.
